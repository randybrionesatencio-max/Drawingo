package dev.sketchpad

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.provider.MediaStore

private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
private val path = Path()

/** Dibuja un trazo suavizado (curvas cuadráticas entre puntos medios). */
private fun drawStroke(c: Canvas, s: Stroke) {
    paint.reset()
    paint.isAntiAlias = true
    paint.strokeCap = Paint.Cap.ROUND
    paint.strokeJoin = Paint.Join.ROUND
    paint.strokeWidth = s.width
    if (s.tool == Tool.ERASER) {
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        paint.color = Color.BLACK
    } else {
        paint.color = s.color
        paint.alpha = (s.alpha * 255).toInt().coerceIn(0, 255)
    }
    val pts = s.points
    if (pts.size == 1) {
        paint.style = Paint.Style.FILL
        c.drawCircle(pts[0].x, pts[0].y, s.width / 2f, paint)
        return
    }
    paint.style = Paint.Style.STROKE
    path.rewind()
    path.moveTo(pts[0].x, pts[0].y)
    for (i in 1 until pts.size - 1) {
        val a = pts[i]
        val b = pts[i + 1]
        path.quadTo(a.x, a.y, (a.x + b.x) / 2f, (a.y + b.y) / 2f)
    }
    path.lineTo(pts.last().x, pts.last().y)
    c.drawPath(path, paint)
}

/** Renderiza el documento completo (usado en pantalla y al exportar). */
fun renderDocument(
    c: Canvas,
    layers: List<Layer>,
    liveStroke: Stroke? = null,
    liveLayerId: Int = -1,
) {
    val w = DOC_W.toFloat()
    val h = DOC_H.toFloat()
    c.save()
    c.clipRect(0f, 0f, w, h)
    c.drawColor(Color.WHITE)
    for (layer in layers) {
        if (!layer.visible) continue
        val sc = c.saveLayerAlpha(0f, 0f, w, h, (layer.opacity * 255).toInt().coerceIn(0, 255))
        for (s in layer.strokes) drawStroke(c, s)
        if (liveStroke != null && layer.id == liveLayerId) drawStroke(c, liveStroke)
        c.restoreToCount(sc)
    }
    c.restore()
}

fun saveToGallery(context: Context, layers: List<Layer>): Boolean {
    val bmp = Bitmap.createBitmap(DOC_W, DOC_H, Bitmap.Config.ARGB_8888)
    renderDocument(Canvas(bmp), layers)
    val values = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "sketch_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Sketchpad")
    }
    val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        ?: return false
    context.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    bmp.recycle()
    return true
}
