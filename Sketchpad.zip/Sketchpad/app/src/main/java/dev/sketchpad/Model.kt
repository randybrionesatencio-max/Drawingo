package dev.sketchpad

import android.graphics.Color as AColor
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.ViewModel
import kotlin.math.hypot
import kotlin.math.min

const val DOC_W = 2048
const val DOC_H = 2048

enum class Tool(val label: String) { PEN("Pluma"), MARKER("Marcador"), ERASER("Borrador") }

class Stroke(
    val id: Long,
    val points: List<Offset>,
    val color: Int,
    val width: Float,
    val alpha: Float,
    val tool: Tool,
)

class Layer(val id: Int, name: String) {
    var name by mutableStateOf(name)
    var visible by mutableStateOf(true)
    var opacity by mutableFloatStateOf(1f)
    val strokes = mutableStateListOf<Stroke>()
}

class DrawingViewModel : ViewModel() {
    val layers = mutableStateListOf(Layer(1, "Capa 1"))
    var activeLayerId by mutableIntStateOf(1)

    var tool by mutableStateOf(Tool.PEN)
    var color by mutableIntStateOf(AColor.BLACK)
    var brushSize by mutableFloatStateOf(12f)
    var brushAlpha by mutableFloatStateOf(1f)

    var scale by mutableFloatStateOf(1f)
    var offset by mutableStateOf(Offset.Zero)
    private var viewW = 0f
    private var viewH = 0f
    private var fitted = false

    val live = mutableStateListOf<Offset>()
    val undoStack = mutableStateListOf<Pair<Int, Stroke>>()
    val redoStack = mutableStateListOf<Pair<Int, Stroke>>()

    private var nextLayerId = 2
    private var nextStrokeId = 1L

    private val activeLayer get() = layers.firstOrNull { it.id == activeLayerId }

    // ---------- Vista (zoom / desplazamiento) ----------
    fun onViewSize(w: Float, h: Float) {
        viewW = w; viewH = h
        if (!fitted && w > 0 && h > 0) resetView()
    }

    fun resetView() {
        val s = min(viewW / DOC_W, viewH / DOC_H) * 0.95f
        scale = s
        offset = Offset((viewW - DOC_W * s) / 2f, (viewH - DOC_H * s) / 2f)
        fitted = true
    }

    fun toDoc(p: Offset): Offset = (p - offset) / scale

    fun transform(centroid: Offset, zoom: Float, pan: Offset) {
        val docPt = (centroid - offset) / scale
        val newScale = (scale * zoom).coerceIn(0.1f, 10f)
        scale = newScale
        offset = centroid - docPt * newScale + pan
    }

    // ---------- Trazos ----------
    private fun effectiveWidth() = when (tool) {
        Tool.PEN -> brushSize
        Tool.MARKER -> brushSize * 2f
        Tool.ERASER -> brushSize * 2f
    }

    private fun effectiveAlpha() = when (tool) {
        Tool.MARKER -> brushAlpha * 0.5f
        else -> brushAlpha
    }

    private fun build(id: Long, pts: List<Offset>) =
        Stroke(id, pts, color, effectiveWidth(), effectiveAlpha(), tool)

    fun liveStroke(): Stroke? = if (live.isEmpty()) null else build(0L, live.toList())

    fun beginStroke(docPoint: Offset) {
        live.clear(); live.add(docPoint)
    }

    fun extendStroke(docPoint: Offset) {
        val last = live.lastOrNull() ?: return
        if (hypot(docPoint.x - last.x, docPoint.y - last.y) >= 0.75f) live.add(docPoint)
    }

    fun cancelStroke() = live.clear()

    fun endStroke() {
        val layer = activeLayer
        if (layer != null && layer.visible && live.isNotEmpty()) {
            val s = build(nextStrokeId++, live.toList())
            layer.strokes.add(s)
            undoStack.add(layer.id to s)
            redoStack.clear()
        }
        live.clear()
    }

    fun undo() {
        val (layerId, s) = undoStack.removeLastOrNull() ?: return
        layers.firstOrNull { it.id == layerId }?.strokes?.removeAll { it.id == s.id }
        redoStack.add(layerId to s)
    }

    fun redo() {
        val (layerId, s) = redoStack.removeLastOrNull() ?: return
        layers.firstOrNull { it.id == layerId }?.strokes?.add(s)
        undoStack.add(layerId to s)
    }

    // ---------- Capas ----------
    fun addLayer() {
        val l = Layer(nextLayerId, "Capa $nextLayerId")
        nextLayerId++
        layers.add(l)
        activeLayerId = l.id
    }

    fun deleteLayer(id: Int) {
        if (layers.size <= 1) return
        layers.removeAll { it.id == id }
        undoStack.removeAll { it.first == id }
        redoStack.removeAll { it.first == id }
        if (activeLayerId == id) activeLayerId = layers.last().id
    }

    fun clearLayer(id: Int) {
        layers.firstOrNull { it.id == id }?.strokes?.clear()
        undoStack.removeAll { it.first == id }
        redoStack.removeAll { it.first == id }
    }

    fun moveLayer(id: Int, dir: Int) {
        val i = layers.indexOfFirst { it.id == id }
        val j = i + dir
        if (i < 0 || j !in layers.indices) return
        val l = layers.removeAt(i)
        layers.add(j, l)
    }
}
