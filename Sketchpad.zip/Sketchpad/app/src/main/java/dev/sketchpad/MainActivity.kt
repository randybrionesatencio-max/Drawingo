package dev.sketchpad

import android.widget.Toast
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: DrawingViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { DrawingScreen(vm) }
            }
        }
    }
}

private val PALETTE = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFF9E9E9E, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835,
    0xFF43A047, 0xFF00ACC1, 0xFF1E88E5, 0xFF5E35B1, 0xFFD81B60, 0xFF6D4C41,
).map { it.toInt() }

@Composable
fun DrawingScreen(vm: DrawingViewModel) {
    val context = LocalContext.current
    var showLayers by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            TextButton(onClick = { vm.undo() }, enabled = vm.undoStack.isNotEmpty()) { Text("↶") }
            TextButton(onClick = { vm.redo() }, enabled = vm.redoStack.isNotEmpty()) { Text("↷") }
            TextButton(onClick = { vm.resetView() }) { Text("Ajustar") }
            TextButton(onClick = { showLayers = !showLayers }) { Text("Capas") }
            TextButton(onClick = {
                val ok = saveToGallery(context, vm.layers)
                Toast.makeText(context, if (ok) "Guardado en Galería" else "Error al guardar", Toast.LENGTH_SHORT).show()
            }) { Text("Guardar") }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            DrawingCanvas(vm, Modifier.fillMaxSize())
            if (showLayers) LayerPanel(vm, Modifier.align(Alignment.TopEnd).padding(8.dp))
        }
        ToolPanel(vm)
    }
}

@Composable
fun DrawingCanvas(vm: DrawingViewModel, modifier: Modifier = Modifier) {
    Canvas(
        modifier
            .clipToBounds()
            .onSizeChanged { vm.onViewSize(it.width.toFloat(), it.height.toFloat()) }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    var multi = false
                    vm.beginStroke(vm.toDoc(down.position))
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed >= 2) {
                            // Dos dedos: zoom y desplazamiento (se descarta el trazo en curso)
                            if (!multi) { multi = true; vm.cancelStroke() }
                            vm.transform(event.calculateCentroid(), event.calculateZoom(), event.calculatePan())
                            event.changes.forEach { it.consume() }
                        } else if (!multi) {
                            val ch = event.changes.first()
                            if (ch.pressed) {
                                vm.extendStroke(vm.toDoc(ch.position))
                                ch.consume()
                            }
                        }
                    } while (event.changes.any { it.pressed })
                    if (!multi) vm.endStroke() else vm.cancelStroke()
                }
            },
    ) {
        drawRect(Color(0xFF3A3A3A))
        drawIntoCanvas { c ->
            val n = c.nativeCanvas
            n.save()
            n.translate(vm.offset.x, vm.offset.y)
            n.scale(vm.scale, vm.scale)
            renderDocument(n, vm.layers, vm.liveStroke(), vm.activeLayerId)
            n.restore()
        }
    }
}

@Composable
fun ToolPanel(vm: DrawingViewModel) {
    Column(Modifier.fillMaxWidth().padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Tool.values().forEach { t ->
                FilterChip(selected = vm.tool == t, onClick = { vm.tool = t }, label = { Text(t.label) })
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(PALETTE) { c ->
                val selected = vm.color == c
                Box(
                    Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (selected) 3.dp else 1.dp, if (selected) Color.Cyan else Color.Gray, CircleShape)
                        .clickable {
                            vm.color = c
                            if (vm.tool == Tool.ERASER) vm.tool = Tool.PEN
                        },
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Tamaño", Modifier.width(72.dp))
            Slider(vm.brushSize, { vm.brushSize = it }, valueRange = 1f..120f)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Opacidad", Modifier.width(72.dp))
            Slider(vm.brushAlpha, { vm.brushAlpha = it }, valueRange = 0.05f..1f)
        }
    }
}

@Composable
fun LayerPanel(vm: DrawingViewModel, modifier: Modifier = Modifier) {
    Card(modifier.width(240.dp)) {
        Column(Modifier.padding(8.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Capas")
                TextButton(onClick = { vm.addLayer() }) { Text("+ Nueva") }
            }
            vm.layers.reversed().forEach { layer ->
                val active = layer.id == vm.activeLayerId
                Column(
                    Modifier
                        .fillMaxWidth()
                        .background(if (active) Color(0x3300BCD4) else Color.Transparent)
                        .clickable { vm.activeLayerId = layer.id }
                        .padding(4.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(layer.visible, { layer.visible = it })
                        Text(layer.name)
                    }
                    if (active) {
                        Slider(layer.opacity, { layer.opacity = it }, valueRange = 0f..1f)
                        Row {
                            TextButton(onClick = { vm.moveLayer(layer.id, 1) }) { Text("▲") }
                            TextButton(onClick = { vm.moveLayer(layer.id, -1) }) { Text("▼") }
                            TextButton(onClick = { vm.clearLayer(layer.id) }) { Text("Vaciar") }
                            TextButton(onClick = { vm.deleteLayer(layer.id) }, enabled = vm.layers.size > 1) { Text("🗑") }
                        }
                    }
                }
            }
        }
    }
}
